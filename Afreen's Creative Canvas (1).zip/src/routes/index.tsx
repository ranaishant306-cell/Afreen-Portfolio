import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import { MagneticCursor } from "@/components/MagneticCursor";
import { MouseTrail } from "@/components/MouseTrail";
import { FloatingTags } from "@/components/FloatingTags";
import { SmoothScroll } from "@/components/SmoothScroll";
import { Reveal, RevealText } from "@/components/Reveal";
import { IntroLoader } from "@/components/IntroLoader";
import { DottedBackground } from "@/components/DottedBackground";
import { DesignInAction, type DiaProject } from "@/components/DesignInAction";

import portrait from "@/assets/afreen-portrait.png";
import innitImg from "@/assets/innit-marketing.png";
import pahadiImg from "@/assets/pahadi-bhula.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Afreen Ilyas Patel — Multidisciplinary Designer" },
      { name: "description", content: "Minimal portfolio of Afreen Ilyas Patel — UX/UI, graphic design and illustration." },
      { property: "og:title", content: "Afreen Ilyas Patel — Multidisciplinary Designer" },
      { property: "og:description", content: "UX/UI, graphic design and illustration portfolio." },
    ],
  }),
  component: Index,
});

type Project = { title: string; category: string; year: string; image: string; link?: string };

const uxProjects: Project[] = [
  { title: "Multisensory IoT Navigation", category: "UX Research · IoT", year: "2025",
    image: "https://mir-s3-cdn-cf.behance.net/projects/404/933cf6250091087.Y3JvcCw1MjM2LDQwOTYsMjU5LDA.png",
    link: "https://www.behance.net/gallery/250091087/Multisensory-IoT-Navigation-Ecosystem" },
  { title: "Nirdesh", category: "UX / UI", year: "2025",
    image: "https://mir-s3-cdn-cf.behance.net/projects/404/ccaec1230499187.Y3JvcCw1NjE1LDQzOTIsNTE0LDA.jpg",
    link: "https://www.behance.net/gallery/230499187/Nirdesh" },
  { title: "EV Charging Experience", category: "Service Design", year: "2025",
    image: "https://mir-s3-cdn-cf.behance.net/projects/404/f53b57240063285.Y3JvcCwyMjA2LDE3MjUsMjU2LDExMzgw.png",
    link: "https://www.behance.net/gallery/240063285/EV-Charging-Experience" },
  { title: "NavDisha", category: "Mobile UX", year: "2024",
    image: "https://mir-s3-cdn-cf.behance.net/projects/404/0d2a78240446303.Y3JvcCwyMzkyLDE4NzEsMzE5LDA.png",
    link: "https://www.behance.net/gallery/240446303/NavDisha" },
  { title: "Innit Marketing", category: "Website Design · Live", year: "2025",
    image: innitImg,
    link: "https://innitmarketing.com/" },
  { title: "Pahadi Bhula Production", category: "Website Design · Live", year: "2025",
    image: pahadiImg,
    link: "https://www.pahadibhulaproduction.in/" },
];

const graphicProjects: Project[] = [
  { title: "Editorial Series", category: "Print · Layout", year: "2024", image: "https://picsum.photos/seed/graphic-a/900/1100" },
  { title: "Brand Identity — Studio Noor", category: "Identity", year: "2024", image: "https://picsum.photos/seed/graphic-b/900/1100" },
  { title: "Poster Suite", category: "Type · Poster", year: "2023", image: "https://picsum.photos/seed/graphic-c/900/1100" },
  { title: "Packaging Concept", category: "Packaging", year: "2023", image: "https://picsum.photos/seed/graphic-d/900/1100" },
];

const illustrationProjects: Project[] = [
  { title: "Quiet Mornings", category: "Procreate", year: "2024", image: "https://picsum.photos/seed/illu-a/900/900" },
  { title: "Botanical Studies", category: "Ink · Watercolor", year: "2024", image: "https://picsum.photos/seed/illu-b/900/900" },
  { title: "Folk Series", category: "Vector", year: "2023", image: "https://picsum.photos/seed/illu-c/900/900" },
  { title: "Character Sketches", category: "Procreate", year: "2023", image: "https://picsum.photos/seed/illu-d/900/900" },
];

function HorizontalRow({ items, aspect = "aspect-[4/5]" }: { items: Project[]; aspect?: string }) {
  return (
    <div className="-mx-6 md:-mx-10 overflow-x-auto no-scrollbar">
      <div className="flex gap-5 px-6 md:px-10 pb-2 snap-x snap-mandatory">
        {items.map((p, i) => (
          <Reveal key={p.title} delay={i * 0.05}>
            <a
              href={p.link}
              target={p.link ? "_blank" : undefined}
              rel="noreferrer"
              data-magnetic
              className="zoom-card group block snap-start shrink-0 w-[72vw] sm:w-[44vw] md:w-[30vw] lg:w-[22vw]"
            >
              <div className={`overflow-hidden bg-muted ${aspect} mb-3 rounded-sm`}>
                <img src={p.image} alt={p.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="font-display font-medium text-sm md:text-base truncate">{p.title}</h3>
                <span className="text-[9px] uppercase tracking-[0.3em] text-muted-foreground shrink-0">{p.year}{p.link ? " ↗" : ""}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">{p.category}</p>
            </a>
          </Reveal>
        ))}
      </div>
    </div>
  );
}

/** Sticky horizontal scroll: section pins, cards translate left as you scroll. */
function StickyHorizontal({ items, title, eyebrow, aspect = "aspect-[4/5]" }: { items: Project[]; title: React.ReactNode; eyebrow: string; aspect?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  // total horizontal travel — moves through all cards
  const x = useTransform(scrollYProgress, [0, 1], ["2%", "-78%"]);

  return (
    <section ref={ref} className="relative" style={{ height: `${100 + items.length * 55}vh` }}>
      <div className="sticky top-0 h-screen flex flex-col overflow-hidden">
        <div className="flex items-end justify-between px-6 md:px-10 pt-28 pb-8 shrink-0">
          <div>
            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-2">{eyebrow}</div>
            <h2 className="font-display font-black text-3xl md:text-5xl leading-none">{title}</h2>
          </div>
          <span className="hidden md:block text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Scroll ↓ → cards →</span>
        </div>
        <div className="flex-1 flex items-center">
          <motion.div style={{ x }} className="flex gap-6 md:gap-10 pl-6 md:pl-10 will-change-transform">
            {items.map((p) => (
              <a
                key={p.title}
                href={p.link}
                target={p.link ? "_blank" : undefined}
                rel="noreferrer"
                data-magnetic
                className="zoom-card group block shrink-0 w-[70vw] sm:w-[46vw] md:w-[34vw] lg:w-[28vw]"
              >
                <div className={`overflow-hidden bg-muted ${aspect} mb-4 rounded-sm`}>
                  <img src={p.image} alt={p.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                </div>
                <div className="flex items-baseline justify-between gap-3">
                  <h3 className="font-display font-medium text-base md:text-lg truncate">{p.title}</h3>
                  <span className="text-[9px] uppercase tracking-[0.3em] text-muted-foreground shrink-0">{p.year}{p.link ? " ↗" : ""}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{p.category}</p>
              </a>
            ))}
            <div className="shrink-0 w-[40vw]" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Index() {
  const [time, setTime] = useState("");
  useEffect(() => {
    const update = () => setTime(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" }));
    update();
    const id = setInterval(update, 30000);
    return () => clearInterval(id);
  }, []);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress: heroProg } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  // Portrait zooms IN as you scroll, then fades
  // Starts zoomed IN, zooms OUT as you scroll
  const rawScale = useTransform(heroProg, [0, 1], [1.45, 0.85]);
  const portraitScale = useSpring(rawScale, { stiffness: 90, damping: 22, mass: 0.4 });
  const portraitY = useTransform(heroProg, [0, 1], [0, -60]);
  const heroOpacity = useTransform(heroProg, [0, 0.85], [1, 0]);

  return (
    <>
      <IntroLoader />
      <SmoothScroll />
      <MagneticCursor />
      <MouseTrail />
      <DottedBackground />
      <main className="min-h-screen text-foreground overflow-x-hidden relative z-10 bg-transparent">



        {/* NAV */}
        <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/50">
          <div className="flex items-center justify-between px-6 md:px-10 py-4">
            <a href="#top" className="font-display font-black text-sm tracking-tight">AIP</a>
            <nav className="hidden md:flex items-center gap-10 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              <a href="#work" className="hover:text-foreground transition-colors">Work</a>
              <a href="#graphic" className="hover:text-foreground transition-colors">Graphic</a>
              <a href="#illustration" className="hover:text-foreground transition-colors">Illustration</a>
              <a href="#about" className="hover:text-foreground transition-colors">About</a>
              <a href="#contact" className="hover:text-foreground transition-colors">Contact</a>
            </nav>
            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground tabular-nums">IN · {time}</div>
          </div>
        </header>

        {/* HERO — massive name, portrait integrated, scroll-zoom */}
        <section ref={heroRef} id="top" className="relative pt-28 md:pt-32 pb-10 px-6 md:px-10 min-h-[100dvh] flex flex-col justify-center">
          <FloatingTags />
          <motion.div style={{ opacity: heroOpacity }} className="relative z-10 w-full">

            {/* Massive name — full width, dominant */}
            <div className="relative">
              <h1
                className="font-display font-black uppercase leading-[0.78] tracking-[-0.04em] text-center select-none"
                style={{ fontSize: "clamp(4.5rem, 22vw, 24rem)" }}
              >
                <span className="block"><RevealText text="Afreen" /></span>
                <span className="block"><RevealText text="Ilyas" /></span>
              </h1>

              {/* Portrait floating inside the hero, overlapping text */}
              <motion.div
                style={{ y: portraitY, scale: portraitScale }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[45%] w-[160px] md:w-[280px] lg:w-[360px] will-change-transform pointer-events-none"
              >
                <span
                  aria-hidden
                  className="absolute -inset-4 rounded-full -z-10"
                  style={{ background: "radial-gradient(closest-side, #B6CDB1 0%, transparent 70%)", opacity: 0.45 }}
                />
                <img
                  src={portrait}
                  alt="Afreen Ilyas"
                  className="relative w-full h-auto object-contain select-none"
                />
              </motion.div>
            </div>

            {/* Subtitle line */}
            <div className="mt-8 md:mt-12 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              <span>Portfolio — 2025</span>
              <Reveal delay={0.3}>
                <p className="text-center text-sm md:text-base font-serif-display normal-case normal-tracking leading-relaxed max-w-lg text-muted-foreground">
                  Multidisciplinary designer working across <span className="text-foreground italic">experience</span>, <span className="text-foreground italic">identity</span> and <span className="text-foreground italic">illustration</span>.
                </p>
              </Reveal>
              <span>Available for freelance & full-time</span>
            </div>

          </motion.div>

          <div className="mt-auto flex items-end justify-between text-[10px] uppercase tracking-[0.3em] text-muted-foreground border-t border-border pt-4">
            <span>Based in India</span>
            <span>Scroll ↓</span>
          </div>
        </section>


        {/* MARQUEE */}
        <section className="border-y border-border py-5 overflow-hidden bg-black">
          <div className="flex whitespace-nowrap animate-marquee w-max">
            {Array.from({ length: 8 }).map((_, i) => (
              <span key={i} className="font-serif-display italic text-xl md:text-2xl px-8 flex items-center gap-8 text-white/60">
                UX / UI<span className="text-white">·</span>Graphic<span className="text-white">·</span>Illustration<span className="text-white">·</span>Research<span className="text-white">·</span>
              </span>
            ))}
          </div>
        </section>

        {/* UX/UI WORK — sticky horizontal scroll */}
        <DesignInAction
          eyebrow="01 — Selected work"
          items={uxProjects.map((p, i) => ({
            title: p.title,
            description: `${p.category} · ${p.year}. A selected case study from my UX/UI practice.`,
            image: p.image,
            link: p.link,
            number: `0${i + 1}`,
          })) as DiaProject[]}
        />




        {/* GRAPHIC */}
        <section id="graphic" className="border-t border-border px-6 md:px-10 py-20 md:py-28">
          <div className="flex items-end justify-between mb-10">
            <div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-2">02 — Graphic Design</div>
              <h2 className="font-display font-black text-3xl md:text-5xl leading-none">
                Print <span className="font-serif-display italic font-normal">&amp;</span> Identity
              </h2>
            </div>
            <span className="hidden md:block text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Scroll →</span>
          </div>
          <HorizontalRow items={graphicProjects} aspect="aspect-[3/4]" />
        </section>

        {/* ILLUSTRATION */}
        <section id="illustration" className="border-t border-border px-6 md:px-10 py-20 md:py-28">
          <div className="flex items-end justify-between mb-10">
            <div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-2">03 — Illustration</div>
              <h2 className="font-display font-black text-3xl md:text-5xl leading-none">
                Drawn <span className="font-serif-display italic font-normal">by hand</span>
              </h2>
            </div>
            <span className="hidden md:block text-[10px] uppercase tracking-[0.3em] text-muted-foreground">Scroll →</span>
          </div>
          <HorizontalRow items={illustrationProjects} aspect="aspect-square" />
        </section>

        {/* ABOUT */}
        <section id="about" className="border-t border-border px-6 md:px-10 py-24 md:py-32">
          <div className="grid md:grid-cols-12 gap-10">
            <div className="md:col-span-3 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">04 — About</div>
            <div className="md:col-span-9 space-y-10">
              <Reveal>
                <p className="font-serif-display text-2xl md:text-4xl leading-snug text-balance">
                  I'm Afreen — a designer based in India, working at the intersection of <em>research</em>, <em>interface</em> and <em>visual craft</em>. I make things that feel honest, considered and genuinely useful.
                </p>
              </Reveal>
              <div className="grid md:grid-cols-3 gap-8 pt-8 border-t border-border">
                {[
                  { h: "Practice", items: ["UX Research", "Product & Interface", "Brand Identity", "Illustration"] },
                  { h: "Tools", items: ["Figma · Framer", "Adobe CC · Procreate", "Notion · Miro"] },
                  { h: "Currently", items: ["Open to freelance", "Open to full-time"] },
                ].map((c, i) => (
                  <Reveal key={c.h} delay={i * 0.1}>
                    <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-3">{c.h}</div>
                    <ul className="space-y-1 text-sm">
                      {c.items.map((x) => <li key={x}>{x}</li>)}
                    </ul>
                  </Reveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <motion.section
          id="contact"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1, ease: [0.2, 0.7, 0.2, 1] }}
          className="border-t border-border px-6 md:px-10 py-32 md:py-44 text-center"
        >
          <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-8">05 — Get in touch</div>
          <h2 className="font-display font-black leading-[0.9] tracking-tight" style={{ fontSize: "clamp(2.5rem, 10vw, 9rem)" }}>
            Let's <span className="font-serif-display italic font-normal">make</span><br />things.
          </h2>
          <a href="mailto:afreenilyaspatel@gmail.com" data-magnetic className="inline-block mt-10 text-base md:text-lg underline underline-offset-8 decoration-1 hover:opacity-60 transition-opacity">
            afreenilyaspatel@gmail.com
          </a>
        </motion.section>

        <footer className="border-t border-border px-6 md:px-10 py-6 flex flex-wrap items-center justify-between gap-4 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
          <div>© {new Date().getFullYear()} Afreen Ilyas Patel</div>
          <div className="flex gap-6">
            <a href="https://www.behance.net/afreenpatel" target="_blank" rel="noreferrer" className="hover:text-foreground">Behance</a>
            <a href="#" className="hover:text-foreground">Instagram</a>
            <a href="#" className="hover:text-foreground">LinkedIn</a>
          </div>
        </footer>
      </main>
    </>
  );
}
