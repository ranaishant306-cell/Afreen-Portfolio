import { motion } from "framer-motion";

const tags = [
  { label: "Design Systems", x: "8%", y: "12%", delay: 0, rot: -6 },
  { label: "Branding", x: "78%", y: "22%", delay: 0.3, rot: 4 },
  { label: "Animation", x: "12%", y: "72%", delay: 0.6, rot: 3 },
  { label: "UX Research", x: "72%", y: "78%", delay: 0.9, rot: -5 },
  { label: "Illustration", x: "45%", y: "8%", delay: 0.4, rot: 2 },
  { label: "Identity", x: "52%", y: "88%", delay: 0.7, rot: -3 },
];

/**
 * Floating skill tags — slow bobbing + slight rotation, parallax-style.
 * Sits behind hero content with low opacity so it whispers.
 */
export function FloatingTags() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {tags.map((t) => (
        <motion.span
          key={t.label}
          initial={{ opacity: 0, y: 10 }}
          animate={{
            opacity: 0.85,
            y: [0, -12, 0],
            rotate: [t.rot, t.rot + 2, t.rot],
          }}
          transition={{
            opacity: { duration: 1, delay: t.delay },
            y: { duration: 6 + t.delay, repeat: Infinity, ease: "easeInOut", delay: t.delay },
            rotate: { duration: 7 + t.delay, repeat: Infinity, ease: "easeInOut", delay: t.delay },
          }}
          style={{ left: t.x, top: t.y }}
          className="absolute font-serif-display italic text-xs md:text-sm px-3 py-1.5 rounded-full border backdrop-blur-sm"
        >
          <span
            className="absolute inset-0 rounded-full"
            style={{ background: "rgba(182,205,177,0.35)", borderColor: "#7E9A78" }}
          />
          <span className="relative text-foreground/70">{t.label}</span>
        </motion.span>
      ))}
    </div>
  );
}
