import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";

/**
 * Full-page light sage-green dot grid.
 * After the hero section, a circular "lens" follows the cursor and
 * zooms the dots underneath it (bigger + denser + slightly brighter).
 */
export function DottedBackground() {
  const ref = useRef<HTMLDivElement>(null);
  const lensRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll();
  const ySlow = useTransform(scrollYProgress, [0, 1], [0, -60]);
  const yMid = useTransform(scrollYProgress, [0, 1], [0, -140]);
  const yFast = useTransform(scrollYProgress, [0, 1], [0, -240]);

  const [lensActive, setLensActive] = useState(false);

  // Deterministic scattered sage marks (very light)
  const marks = useMemo(() => {
    const seeded = (n: number) => {
      const x = Math.sin(n * 9301 + 49297) * 233280;
      return x - Math.floor(x);
    };
    const types = ["dot", "cross", "spark", "ring"] as const;
    return Array.from({ length: 70 }).map((_, i) => ({
      id: i,
      x: seeded(i + 1) * 100,
      y: seeded(i + 11) * 280,
      r: (seeded(i + 23) - 0.5) * 40,
      s: 0.6 + seeded(i + 37) * 1.2,
      layer: i % 3,
      type: types[Math.floor(seeded(i + 53) * types.length)],
    }));
  }, []);

  const SAGE = "#7E9A78";

  useEffect(() => {
    let raf = 0;
    let mx = -9999;
    let my = -9999;

    const update = () => {
      raf = 0;
      const lens = lensRef.current;
      if (lens) {
        lens.style.setProperty("--mx", `${mx}px`);
        lens.style.setProperty("--my", `${my}px`);
      }
    };

    const onMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;

      // Activate lens only when cursor is past the hero section (#top)
      const hero = document.getElementById("top");
      if (hero) {
        const rect = hero.getBoundingClientRect();
        setLensActive(e.clientY > rect.bottom);
      }

      if (!raf) raf = requestAnimationFrame(update);
    };

    const onLeave = () => setLensActive(false);

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseleave", onLeave);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseleave", onLeave);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      style={{ background: "linear-gradient(180deg, #faf5ec 0%, #f3ebd9 100%)" }}
    >
      {/* base light sage dot grid — covers entire site */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(rgba(126,154,120,0.22) 1.2px, transparent 1.6px)",
          backgroundSize: "22px 22px",
          backgroundPosition: "0 0",
        }}
      />

      {/* cursor lens — subtle zoomed dots, masked to a small circle around cursor */}
      <div
        ref={lensRef}
        className="absolute inset-0 transition-opacity duration-200"
        style={
          {
            opacity: lensActive ? 1 : 0,
            backgroundImage:
              "radial-gradient(rgba(126,154,120,0.55) 1.6px, transparent 2px)",
            backgroundSize: "22px 22px",
            backgroundPosition: "0 0",
            WebkitMaskImage:
              "radial-gradient(circle 100px at var(--mx, -9999px) var(--my, -9999px), #000 0%, rgba(0,0,0,0.6) 50%, transparent 100%)",
            maskImage:
              "radial-gradient(circle 100px at var(--mx, -9999px) var(--my, -9999px), #000 0%, rgba(0,0,0,0.6) 50%, transparent 100%)",
          } as React.CSSProperties
        }
      />


      {/* parallax doodle marks (sage only, subtle) */}
      {[ySlow, yMid, yFast].map((y, layer) => (
        <motion.div key={layer} style={{ y }} className="absolute inset-0">
          {marks
            .filter((m) => m.layer === layer)
            .map((m) => (
              <span
                key={m.id}
                className="absolute"
                style={{
                  left: `${m.x}%`,
                  top: `${m.y}%`,
                  transform: `translate(-50%,-50%) rotate(${m.r}deg) scale(${m.s})`,
                  color: SAGE,
                  opacity: 0.45,
                }}
              >
                {m.type === "dot" && (
                  <span
                    className="block w-1.5 h-1.5 rounded-full"
                    style={{ background: SAGE }}
                  />
                )}
                {m.type === "cross" && (
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M7 1v12M1 7h12" stroke={SAGE} strokeWidth="1.4" strokeLinecap="round" />
                  </svg>
                )}
                {m.type === "spark" && (
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M8 1c.6 3 2 4.4 5 5-3 .6-4.4 2-5 5-.6-3-2-4.4-5-5 3-.6 4.4-2 5-5z" fill={SAGE} />
                  </svg>
                )}
                {m.type === "ring" && (
                  <span
                    className="block w-3 h-3 rounded-full border"
                    style={{ borderColor: SAGE }}
                  />
                )}
              </span>
            ))}
        </motion.div>
      ))}
    </div>
  );
}
