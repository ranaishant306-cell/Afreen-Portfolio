import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

export function IntroLoader() {
  const [show, setShow] = useState(true);
  const [count, setCount] = useState(0);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (typeof window === "undefined") return;
    document.body.style.overflow = "hidden";

    const start = Date.now();
    const duration = 2400;
    let raf = 0;
    const tick = () => {
      const p = Math.min(1, (Date.now() - start) / duration);
      setCount(Math.floor(p * 100));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    const onMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 2;
      const y = (e.clientY / window.innerHeight - 0.5) * 2;
      setMouse({ x, y });
    };
    window.addEventListener("mousemove", onMove);

    const t = setTimeout(() => {
      setShow(false);
      document.body.style.overflow = "";
    }, duration + 400);

    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(t);
      window.removeEventListener("mousemove", onMove);
      document.body.style.overflow = "";
    };
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="intro"
          initial={{ y: 0 }}
          exit={{ y: "-100%" }}
          transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
          className="fixed inset-0 z-[100] bg-foreground text-background flex flex-col justify-between p-6 md:p-8"
        >
          <div className="flex items-center justify-between text-[10px] uppercase tracking-[0.3em] opacity-60">
            <span>Portfolio — 2025</span>
            <span>India</span>
          </div>

          <div className="flex-1 flex items-center justify-center">
            <motion.div
              style={{ x: mouse.x * 18, y: mouse.y * 12 }}
              transition={{ type: "spring", stiffness: 120, damping: 20 }}
              className="flex items-baseline gap-3"
            >
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="font-display font-black tabular-nums leading-none"
                style={{ fontSize: "clamp(3rem, 8vw, 7rem)" }}
              >
                {String(count).padStart(3, "0")}
              </motion.span>
              <span className="text-[10px] uppercase tracking-[0.3em] opacity-60">%</span>
            </motion.div>
          </div>

          <div className="flex items-end justify-between text-[10px] uppercase tracking-[0.3em] opacity-60">
            <span>Loading experience</span>
            <div className="relative w-40 h-px bg-background/20 overflow-hidden">
              <motion.div
                className="absolute inset-y-0 left-0 bg-background"
                style={{ width: `${count}%` }}
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
