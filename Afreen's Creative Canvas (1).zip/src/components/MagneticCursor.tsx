import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export function MagneticCursor() {
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { damping: 28, stiffness: 320, mass: 0.4 });
  const sy = useSpring(y, { damping: 28, stiffness: 320, mass: 0.4 });
  // Ring follows slower to give a trailing feel
  const rx = useSpring(x, { damping: 22, stiffness: 120, mass: 0.6 });
  const ry = useSpring(y, { damping: 22, stiffness: 120, mass: 0.6 });
  const [hover, setHover] = useState(false);
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    document.documentElement.classList.add("cursor-none-root");
    const move = (e: MouseEvent) => {
      setHidden(false);
      x.set(e.clientX);
      y.set(e.clientY);
      const t = e.target as HTMLElement;
      setHover(!!t.closest("a, button, [data-magnetic]"));
    };
    const leave = () => setHidden(true);
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseleave", leave);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseleave", leave);
      document.documentElement.classList.remove("cursor-none-root");
    };
  }, [x, y]);

  return (
    <>
      {/* outer trailing ring */}
      <motion.div
        aria-hidden
        style={{ x: rx, y: ry, opacity: hidden ? 0 : 1 }}
        className="pointer-events-none fixed top-0 left-0 z-[100]"
      >
        <motion.div
          animate={{
            scale: hover ? 1.8 : 1,
            borderColor: hover ? "#F4C2D0" : "#B6CDB1",
          }}
          transition={{ type: "spring", damping: 20, stiffness: 220 }}
          className="-translate-x-1/2 -translate-y-1/2 w-9 h-9 rounded-full border-2"
          style={{ borderColor: "#B6CDB1" }}
        />
      </motion.div>
      {/* inner dot */}
      <motion.div
        aria-hidden
        style={{ x: sx, y: sy, opacity: hidden ? 0 : 1 }}
        className="pointer-events-none fixed top-0 left-0 z-[101]"
      >
        <motion.div
          animate={{ scale: hover ? 0 : 1 }}
          transition={{ type: "spring", damping: 18, stiffness: 280 }}
          className="-translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full"
          style={{ background: "#1a1a1a" }}
        />
      </motion.div>
    </>
  );
}
