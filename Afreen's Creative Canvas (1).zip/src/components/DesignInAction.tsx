import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Reveal } from "@/components/Reveal";

export type DiaProject = {
  title: string;
  description: string;
  image: string;
  link?: string;
  number?: string;
};

/** Folder-tab card, tilted slightly, with device-mockup image on the right. */
function FolderCard({ p, index }: { p: DiaProject; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const rotate = useTransform(scrollYProgress, [0, 0.5, 1], [3, 0, -3]);

  return (
    <div ref={ref} className="relative px-6 md:px-10 mb-24 md:mb-40">
      <motion.div
        style={{ y, rotate }}
        className="relative mx-auto max-w-6xl"
      >
        {/* folder tab */}
        <div className="relative ml-6 md:ml-16 w-fit">
          <div
            className="px-6 md:px-8 py-2.5 rounded-t-2xl border border-b-0 border-foreground/15 bg-[#f7f1e3] font-display font-medium text-sm md:text-base"
            style={{ filter: "drop-shadow(0 -2px 6px rgba(0,0,0,0.04))" }}
          >
            Project {p.number ?? String(index + 1).padStart(2, "0")}
          </div>
        </div>

        {/* card */}
        <div
          className="relative grid md:grid-cols-2 gap-8 md:gap-10 items-center rounded-3xl border border-foreground/15 bg-[#f7f1e3] p-7 md:p-12"
          style={{ boxShadow: "0 30px 80px -40px rgba(0,0,0,0.25), 0 8px 24px -12px rgba(0,0,0,0.08)" }}
        >
          <div className="space-y-5 md:space-y-7">
            <Reveal>
              <h3 className="font-display font-black uppercase text-3xl md:text-5xl leading-[0.95] tracking-tight">
                {p.title}
              </h3>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="font-serif-display text-base md:text-lg leading-relaxed text-foreground/75 max-w-md">
                {p.description}
              </p>
            </Reveal>
            <Reveal delay={0.2}>
              <a
                href={p.link}
                target={p.link ? "_blank" : undefined}
                rel="noreferrer"
                data-magnetic
                className="inline-flex items-center gap-2 text-[11px] md:text-xs uppercase tracking-[0.4em] text-[#5b7a89] hover:text-foreground transition-colors"
              >
                View Project →
              </a>
            </Reveal>
          </div>

          {/* tilted device-style mockup */}
          <Reveal delay={0.15}>
            <motion.div
              whileHover={{ rotate: -2, scale: 1.02 }}
              transition={{ type: "spring", stiffness: 150, damping: 18 }}
              className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-white border border-foreground/10"
              style={{
                transform: "perspective(1200px) rotateY(-6deg) rotateX(2deg)",
                boxShadow: "0 30px 60px -30px rgba(0,0,0,0.35)",
              }}
            >
              <img
                src={p.image}
                alt={p.title}
                loading="lazy"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </Reveal>
        </div>
      </motion.div>
    </div>
  );
}

export function DesignInAction({ items, eyebrow }: { items: DiaProject[]; eyebrow: string }) {
  return (
    <section id="work" className="relative py-24 md:py-32">
      <div className="text-center mb-16 md:mb-24 px-6">
        <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-4">{eyebrow}</div>
        <h2
          className="font-display font-black uppercase leading-[0.85] tracking-[-0.03em]"
          style={{ fontSize: "clamp(2.5rem, 9vw, 8rem)" }}
        >
          Design <span className="font-serif-display italic font-normal">in</span> Action
        </h2>
      </div>
      {items.map((p, i) => (
        <FolderCard key={p.title} p={p} index={i} />
      ))}
    </section>
  );
}
