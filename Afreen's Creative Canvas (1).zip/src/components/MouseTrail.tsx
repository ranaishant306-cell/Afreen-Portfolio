import { useEffect, useRef } from "react";

/**
 * Sage-green cursor trail constrained to a target element (e.g. the hero section).
 * Pass a CSS selector via `boundsSelector`; trail only draws while the cursor is
 * within that element's bounding rect.
 */
export function MouseTrail({ boundsSelector = "#top" }: { boundsSelector?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const resize = () => {
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = window.innerWidth + "px";
      canvas.style.height = window.innerHeight + "px";
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);
    };
    resize();
    window.addEventListener("resize", resize);

    type P = { x: number; y: number; life: number };
    const points: P[] = [];
    const maxLife = 55;

    const inBounds = (x: number, y: number) => {
      const el = document.querySelector(boundsSelector) as HTMLElement | null;
      if (!el) return false;
      const r = el.getBoundingClientRect();
      return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
    };

    const onMove = (e: MouseEvent) => {
      if (!inBounds(e.clientX, e.clientY)) {
        // break the line so it doesn't connect across gaps
        if (points.length && points[points.length - 1].life > 0) {
          points.push({ x: e.clientX, y: e.clientY, life: 0 });
        }
        return;
      }
      points.push({ x: e.clientX, y: e.clientY, life: maxLife });
      if (points.length > 80) points.shift();
    };
    window.addEventListener("mousemove", onMove);

    let raf = 0;
    const tick = () => {
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      for (let i = 1; i < points.length; i++) {
        const a = points[i - 1];
        const b = points[i];
        if (a.life <= 0 || b.life <= 0) continue;
        const alpha = (b.life / maxLife) * 0.9;
        ctx.strokeStyle = `rgba(126,154,120,${alpha})`;
        ctx.lineWidth = 2 + (b.life / maxLife) * 2;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        b.life -= 1;
      }
      while (points.length && points[0].life <= 0) points.shift();
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
    };
  }, [boundsSelector]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden
      className="pointer-events-none fixed inset-0 z-[90]"
    />
  );
}
